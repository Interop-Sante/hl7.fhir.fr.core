# FR Core CodeSystem Marital Status - Guide d'implémentation FR Core v2.2.0

## CodeSystem: FR Core CodeSystem Marital Status 

 
Marital status 

Ce système de codes est référencé dans la définition des ensembles de valeurs suivants :

* [FRCoreValueSetMaritalStatus](ValueSet-fr-core-vs-marital-status.md)

-------

 [Description du (des) tableau(x) ci-dessus](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "fr-core-cs-marital-status",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablecodesystem|4.0.1"]
  },
  "language" : "fr-FR",
  "url" : "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-marital-status",
  "version" : "2.2.0",
  "name" : "FRCoreCodeSystemMaritalStatus",
  "title" : "FR Core CodeSystem Marital Status",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-07-23T09:54:31+00:00",
  "publisher" : "Interop'Santé",
  "contact" : [{
    "name" : "Interop'Santé",
    "telecom" : [{
      "system" : "url",
      "value" : "http://interopsante.org"
    }]
  },
  {
    "name" : "InteropSanté",
    "telecom" : [{
      "system" : "email",
      "value" : "fhir@interopsante.org",
      "use" : "work"
    }]
  }],
  "description" : "Marital status",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 1,
  "concept" : [{
    "code" : "PACS",
    "display" : "PACS",
    "definition" : "PACS"
  }]
}

```
