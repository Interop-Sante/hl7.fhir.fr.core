# FRCoreObservationBMIExample - Guide d'implémentation FR Core v3.0.0-ballot

## Example Observation: FRCoreObservationBMIExample

-------

**English**

-------

Profile: [FR Core Observation Bmi Profile](StructureDefinition-fr-core-observation-bmi.md)

**status**: Final

**category**: Vital Signs

**code**: Indice de masse corporelle [Ratio] Patient ; Numérique

**subject**: [Pierre Durand (official) Male, DoB: 1974-12-25 ( NIR définitif (use: official, ))](Patient-FRCorePatientINSExample.md)

**effective**: 2022-11-06

**performer**: [Practitioner Leclerc Sophie](Practitioner-FRCorePractitionerExample.md)

**value**: 28 Kg/m2 (Details: UCUM codekg/m2 = 'kg/m2')

**interpretation**: Anormalement haut



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "FRCoreObservationBMIExample",
  "meta" : {
    "profile" : ["https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-observation-bmi"]
  },
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "vital-signs"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "39156-5"
    }]
  },
  "subject" : {
    "reference" : "Patient/FRCorePatientINSExample",
    "type" : "Patient"
  },
  "effectiveDateTime" : "2022-11-06",
  "performer" : [{
    "reference" : "Practitioner/FRCorePractitionerExample"
  }],
  "valueQuantity" : {
    "value" : 28,
    "unit" : "Kg/m2",
    "system" : "http://unitsofmeasure.org",
    "code" : "kg/m2"
  },
  "interpretation" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
      "code" : "H",
      "display" : "Anormalement haut"
    }]
  }]
}

```
