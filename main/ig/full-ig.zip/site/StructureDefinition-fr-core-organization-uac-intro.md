### Usage

L'[UAC](structure_entites.html#UAC) est lié à une discipline de prestation et à un tarif (lié à la discipline de prestation). Elle ne sert qu’à la facturation du séjour.
Elle permet d’associer des tarifs de soins différents pour la prise en charge d’un patient.

### Ajout du profil FR

Ce profil ajoute par rapport au profil FR Organization, dont il hérite :
- la possibilité de définir une discipline de prestation
- la possibilité d'ajouter un code tarif