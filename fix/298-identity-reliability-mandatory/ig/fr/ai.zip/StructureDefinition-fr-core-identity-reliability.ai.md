# FR Core Patient Identity Reliability Extension - Guide d'implémentation FR Core v2.2.0

## Extension: FR Core Patient Identity Reliability Extension 

Extension composite précisant le degré de confiance de l’identité du patient au sens du Référentiel National d’Identitovigilance (RNIV) : statut de confiance (provisoire, récupérée, validée, qualifiée), canal d’obtention des traits d’identité ou du matricule INS, pièce justificative contrôlée, dates associées et annotations complémentaires. Composite extension specifying the confidence level of a patient’s identity per the French National Identity Vigilance Framework (RNIV): trust status (provisional, recovered, validated, qualified), channel used to collect the identity traits or the INS identifier, validation evidence, related dates and additional annotations.

**Context of Use**

### Usage

Cette extension composite, positionnée sur `Patient`, permet de documenter le degré de confiance accordé à l’identité d’un patient ainsi que les éléments qui ont permis d’établir ce degré de confiance (mode d’obtention de l’INS, contrôle de cohérence, justificatif utilisé…). Elle est **obligatoire** (`1..*`) sur `Patient` : toute ressource conforme à `fr-core-patient` (ou `fr-core-patient-ins`) doit porter au moins une instance de cette extension.

Elle regroupe 7 sous-extensions :

| | | | |
| :--- | :--- | :--- | :--- |
| `lastUpdated` | 1..1 | Horodatage de la dernière mise à jour de cette instance de l’extension, permettant d’ordonner un historique lorsque plusieurs instances de`identityReliability`coexistent sur une même ressource | `dateTime` |
| `methodCollection` | 0..1 | Canal d’obtention des traits d’identité ou du matricule INS (saisie manuelle, carte Vitale, INSi, code à barre, RFID, Application carte Vitale) | [fr-core-vs-identity-method-collection](ValueSet-fr-core-vs-identity-method-collection.md) |
| `dateInterrogationINSi` | 0..1 | Date d’interrogation du téléservice INSi | `date` |
| `identityStatus` | 0..1 | Statut de confiance de l’identité au sens du RNIV (`PROV`,`RECUP`,`VALI`,`QUAL`) | [fr-core-vs-identity-status](ValueSet-fr-core-vs-identity-status.md) |
| `comment` | 0..* | Annotations complémentaires sur l’identité (attributs RNIV, codes de gestion) | [fr-core-vs-identity-status-comment](ValueSet-fr-core-vs-identity-status-comment.md) |
| `validationDate` | 0..1 | Date de vérification de l’identité | `date` |
| `validationMode` | 0..1 | Type de document contrôlé pour justifier le statut de l’identité (CN, PA, CS…) | [fr-core-vs-mode-validation-identity](ValueSet-fr-core-vs-mode-validation-identity.md) |

### Statut de confiance de l’identité

Le détail des 4 statuts de confiance RNIV (`PROV`, `RECUP`, `VALI`, `QUAL`) portés par la sous-extension `identityStatus` est décrit sur la page du ValueSet [fr-core-vs-identity-status](ValueSet-fr-core-vs-identity-status.md).

### À ne pas confondre : canal de capture, statut de confiance et pièce justificative

Ces quatre sous-extensions couvrent des axes distincts du RNIV et ne doivent pas être confondues :

* `methodCollection` documente le **canal de capture** par lequel les traits d’identité ou le matricule INS ont été obtenus (RNIV §4.3) — c’est une information de traçabilité, elle ne détermine pas à elle seule le statut de confiance résultant. 
* `dateInterrogationINSi` documente la **date d’interrogation du téléservice INSi** — renseignée chaque fois que le téléservice INSi est appelé, que ce soit par lecture de la carte Vitale ou par saisie directe des traits, sauf pour les usagers de l’Application carte Vitale et leurs ayants droit, pour lesquels le RNIV exclut explicitement cet appel.
* `identityStatus` documente le **statut de confiance** résultant (RNIV EXI SI 07), croisement des axes I± (récupération INSi) et C± (contrôle de cohérence) — voir la page du ValueSet [fr-core-vs-identity-status](ValueSet-fr-core-vs-identity-status.md).
* `validationMode` documente la **pièce justificative à haut niveau de confiance** contrôlée pour l’axe C± (carte nationale d’identité, passeport, Application carte Vitale…).

### Règles de cohérence entre identityStatus et comment (RNIV EXI SI 09)

Deux règles de cohérence s’appliquent entre le statut de confiance (`identityStatus`) et les attributs RNIV portés par `comment` :

* Une identité comportant l’attribut Identité douteuse (`DOUT`) ou Identité fictive (`FICT`) dans `comment` doit obligatoirement avoir le statut de confiance `PROV` (Identité provisoire) — il est interdit de lui attribuer un autre statut ou d’interroger le téléservice INSi pour cette identité.
* Les attributs Identité fictive (`FICT`) et Identité douteuse (`DOUT`) ne peuvent pas être cumulés dans `comment` sur une même identité.

Le statut `PROV` seul ne signale qu’une identité pas encore vérifiée, sans en préciser la cause. Les attributs `DOUT`/`FICT` permettent de qualifier les situations où ce défaut de vérification n’est pas une simple attente mais un problème identifié — identité douteuse (homonymie non résolue, incohérence des traits), identité fictive (patient anonyme, refusant de s’identifier, identité de test) : toute situation d’identitovigilance reste ainsi représentable, ce qui justifie le caractère désormais obligatoire de l’extension `identityReliability` sur `Patient`.

**Usage info**

**Utilisations:**

* Utilise ce/t/te Extension: [FR Core Patient Profile](StructureDefinition-fr-core-patient.md)
* Exemples pour ce/t/te Extension: [Patient/FRCorePatientDeceasedExample](Patient-FRCorePatientDeceasedExample.md), [Patient/FRCorePatientINSExample](Patient-FRCorePatientINSExample.md) and [Patient/FRCorePatientINSExampleRNIV](Patient-FRCorePatientINSExampleRNIV.md)

Vous pouvez également vérifier [les usages dans le FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.fr.core|current/StructureDefinition/fr-core-identity-reliability)

### Vues formelles du contenu de l'extension

 [Description des profils, des différentiels, des instantanés et de leurs représentations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Tableau différentiel (differential)](#tabs-diff) 
*  [Tableau récapitulatif (snapshot)](#tabs-snap) 
*  [Statistiques/Références](#tabs-summ) 
*  [Tous](#tabs-all) 

Cette structure est dérivée de [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

#### Bindings terminologiques (différentiel)

#### Contraintes

#### Bindings terminologiques

#### Contraintes

Cette structure est dérivée de [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

** Résumé **

Extension complexe: Extension composite précisant le degré de confiance de l'identité du patient au sens du Référentiel National d'Identitovigilance (RNIV) : statut de confiance (provisoire, récupérée, validée, qualifiée), canal d'obtention des traits d'identité ou du matricule INS, pièce justificative contrôlée, dates associées et annotations complémentaires. Composite extension specifying the confidence level of a patient's identity per the French National Identity Vigilance Framework (RNIV): trust status (provisional, recovered, validated, qualified), channel used to collect the identity traits or the INS identifier, validation evidence, related dates and additional annotations.

 **Vue différentielleDifferential View** 

Cette structure est dérivée de [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

#### Bindings terminologiques (différentiel)

#### Contraintes

 **Vue d'ensemble** 

#### Bindings terminologiques

#### Contraintes

Cette structure est dérivée de [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

** Résumé **

Extension complexe: Extension composite précisant le degré de confiance de l'identité du patient au sens du Référentiel National d'Identitovigilance (RNIV) : statut de confiance (provisoire, récupérée, validée, qualifiée), canal d'obtention des traits d'identité ou du matricule INS, pièce justificative contrôlée, dates associées et annotations complémentaires. Composite extension specifying the confidence level of a patient's identity per the French National Identity Vigilance Framework (RNIV): trust status (provisional, recovered, validated, qualified), channel used to collect the identity traits or the INS identifier, validation evidence, related dates and additional annotations.

 

Autres représentations du profil : [CSV](../StructureDefinition-fr-core-identity-reliability.csv), [Excel](../StructureDefinition-fr-core-identity-reliability.xlsx), [Schematron](../StructureDefinition-fr-core-identity-reliability.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "fr-core-identity-reliability",
  "url" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-identity-reliability",
  "version" : "2.2.0",
  "name" : "FRCorePatientIdentityReliabilityExtension",
  "title" : "FR Core Patient Identity Reliability Extension",
  "status" : "active",
  "date" : "2026-09-29T12:37:34+00:00",
  "publisher" : "Interop'Santé",
  "contact" : [{
    "name" : "Interop'Santé",
    "telecom" : [{
      "system" : "url",
      "value" : "http://interopsante.org"
    }]
  },
  {
    "name" : "InteropSanté",
    "telecom" : [{
      "system" : "email",
      "value" : "fhir@interopsante.org",
      "use" : "work"
    }]
  }],
  "description" : "Extension composite précisant le degré de confiance de l'identité du patient au sens du Référentiel National d'Identitovigilance (RNIV) : statut de confiance (provisoire, récupérée, validée, qualifiée), canal d'obtention des traits d'identité ou du matricule INS, pièce justificative contrôlée, dates associées et annotations complémentaires.\r\nComposite extension specifying the confidence level of a patient's identity per the French National Identity Vigilance Framework (RNIV): trust status (provisional, recovered, validated, qualified), channel used to collect the identity traits or the INS identifier, validation evidence, related dates and additional annotations.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "purpose" : "Permet de documenter le degré de confiance de l'identité d'un patient conformément au RNIV, ainsi que les éléments ayant permis de l'établir (canal de collecte, statut, justificatif de contrôle, annotations).\r\nDocuments the confidence level of a patient's identity per the RNIV, along with the elements used to establish it (collection channel, status, validation evidence, annotations).",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "Patient"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension|4.0.1",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "FR Core Patient Identity Reliability Extension",
      "definition" : "Extension composite précisant le degré de confiance de l'identité du patient au sens du Référentiel National d'Identitovigilance (RNIV) : statut de confiance (provisoire, récupérée, validée, qualifiée), canal d'obtention des traits d'identité ou du matricule INS, pièce justificative contrôlée, dates associées et annotations complémentaires.\r\nComposite extension specifying the confidence level of a patient's identity per the French National Identity Vigilance Framework (RNIV): trust status (provisional, recovered, validated, qualified), channel used to collect the identity traits or the INS identifier, validation evidence, related dates and additional annotations.",
      "constraint" : [{
        "key" : "fr-core-identity-reliability-1",
        "severity" : "error",
        "human" : "Une identité comportant l'attribut Identité douteuse (DOUT) ou Identité fictive (FICT) dans `comment` doit avoir un statut de confiance (`identityStatus`) égal à Identité provisoire (PROV) [EXI SI 09]",
        "expression" : "extension('comment').value.coding.exists(code = 'DOUT' or code = 'FICT') implies extension('identityStatus').value.exists(code = 'PROV')",
        "source" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-identity-reliability|2.2.0"
      },
      {
        "key" : "fr-core-identity-reliability-2",
        "severity" : "error",
        "human" : "Les attributs Identité fictive (FICT) et Identité douteuse (DOUT) ne peuvent être cumulés dans `comment` sur une même identité",
        "expression" : "extension('comment').value.coding.where(code = 'FICT').exists() implies extension('comment').value.coding.where(code = 'DOUT').empty()",
        "source" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-identity-reliability|2.2.0"
      }]
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "min" : 1
    },
    {
      "id" : "Extension.extension:lastUpdated",
      "path" : "Extension.extension",
      "sliceName" : "lastUpdated",
      "short" : "Date de dernière mise à jour de cette instance de l'extension, permettant d'ordonner un historique de plusieurs instances de identityReliability sur une même ressource | Date of the last update of this extension instance, used to order the history when several identityReliability instances are present on the same resource",
      "definition" : "Horodatage de la dernière mise à jour de cette instance de l'extension composite identityReliability. Dès lors que plusieurs instances de l'extension identityReliability coexistent sur la même ressource (afin de conserver un historique des statuts de confiance successifs), ce champ permet de les ordonner chronologiquement. | Timestamp of the last update of this identityReliability composite extension instance. When several identityReliability instances coexist on the same resource (to keep a history of successive trust statuses), this field allows them to be ordered chronologically.",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Extension.extension:lastUpdated.extension",
      "path" : "Extension.extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.extension:lastUpdated.url",
      "path" : "Extension.extension.url",
      "fixedUri" : "lastUpdated"
    },
    {
      "id" : "Extension.extension:lastUpdated.value[x]",
      "path" : "Extension.extension.value[x]",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "Extension.extension:methodCollection",
      "path" : "Extension.extension",
      "sliceName" : "methodCollection",
      "short" : "Canal d'obtention des traits d'identité (SM, CV, INSi, CB, RFID, AV) | Channel used to collect the identity traits",
      "definition" : "Précise le canal par lequel les traits d'identité ou le matricule INS ont été obtenus : saisie manuelle, lecture de la carte Vitale, interrogation directe du téléservice INSi, scan d'un code à barre/Datamatrix, lecture RFID ou Application carte Vitale. Ce champ ne porte pas le statut de confiance résultant (cf. sous-extension `identityStatus`) ni la pièce justificative contrôlée (cf. sous-extension `validationMode`).",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Extension.extension:methodCollection.extension",
      "path" : "Extension.extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.extension:methodCollection.url",
      "path" : "Extension.extension.url",
      "fixedUri" : "methodCollection"
    },
    {
      "id" : "Extension.extension:methodCollection.value[x]",
      "path" : "Extension.extension.value[x]",
      "type" : [{
        "code" : "Coding"
      }],
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "https://hl7.fr/ig/fhir/core/ValueSet/fr-core-vs-identity-method-collection|2.2.0"
      }
    },
    {
      "id" : "Extension.extension:dateInterrogationINSi",
      "path" : "Extension.extension",
      "sliceName" : "dateInterrogationINSi",
      "short" : "Date d'interrogation du téléservice INSi | Date the INSi teleservice was queried",
      "definition" : "Date à laquelle le téléservice INSi a été appelé. Ce champ est renseigné chaque fois que le téléservice INSi est interrogé, que ce soit par lecture de la carte Vitale ou par saisie directe des traits d'identité (cf. sous-extension `methodCollection`), à l'exception des usagers de l'Application carte Vitale et de leurs ayants droit, pour lesquels le RNIV exclut explicitement l'appel au téléservice. Cette date ne doit pas être confondue avec la date de vérification de l'identité (cf. sous-extension `validationDate`). | Date at which the INSi teleservice was queried. This field is populated whenever the INSi teleservice is queried, whether via Vitale card reading or direct entry of identity traits (see the `methodCollection` sub-extension), except for Appli carte Vitale users and their dependents, for whom the RNIV explicitly excludes the teleservice call. This date must not be confused with the identity verification date (see the `validationDate` sub-extension).",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Extension.extension:dateInterrogationINSi.extension",
      "path" : "Extension.extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.extension:dateInterrogationINSi.url",
      "path" : "Extension.extension.url",
      "fixedUri" : "dateInterrogationINSi"
    },
    {
      "id" : "Extension.extension:dateInterrogationINSi.value[x]",
      "path" : "Extension.extension.value[x]",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "Extension.extension:identityStatus",
      "path" : "Extension.extension",
      "sliceName" : "identityStatus",
      "short" : "Statut de confiance de l’identité au sens du RNIV (EXI SI 07) : PROV | RECUP | VALI | QUAL. Ces 4 statuts sont exclusifs les uns des autres.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Extension.extension:identityStatus.extension",
      "path" : "Extension.extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.extension:identityStatus.url",
      "path" : "Extension.extension.url",
      "fixedUri" : "identityStatus"
    },
    {
      "id" : "Extension.extension:identityStatus.value[x]",
      "path" : "Extension.extension.value[x]",
      "type" : [{
        "code" : "Coding"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://hl7.fr/ig/fhir/core/ValueSet/fr-core-vs-identity-status|2.2.0"
      }
    },
    {
      "id" : "Extension.extension:comment",
      "path" : "Extension.extension",
      "sliceName" : "comment",
      "short" : "Annotations complémentaires sur l’identité : attributs RNIV (homonyme, douteux, fictif) et codes de gestion (doublon, collision, désactivé…). Plusieurs annotations peuvent coexister.",
      "definition" : "En particulier, les attributs Identité douteuse (DOUT) et Identité fictive (FICT), combinés au statut Identité provisoire (PROV) imposé par les invariants ci-dessous, permettent de qualifier les cas où l'absence de vérification n'est pas une simple attente mais un problème identifié (homonymie non résolue, identité fictive ou anonyme, patient refusant de s'identifier...) : toute situation d'identitovigilance reste ainsi représentable. | In particular, the Doubtful identity (DOUT) and Fictitious identity (FICT) attributes, combined with the mandatory Provisional identity (PROV) status required by the invariants below, make it possible to qualify cases where the lack of verification is not a mere pending state but an identified issue (unresolved homonymy, fictitious or anonymous identity, patient refusing to be identified...): every identity vigilance situation remains representable this way.",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Extension.extension:comment.extension",
      "path" : "Extension.extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.extension:comment.url",
      "path" : "Extension.extension.url",
      "fixedUri" : "comment"
    },
    {
      "id" : "Extension.extension:comment.value[x]",
      "path" : "Extension.extension.value[x]",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "https://hl7.fr/ig/fhir/core/ValueSet/fr-core-vs-identity-status-comment|2.2.0"
      }
    },
    {
      "id" : "Extension.extension:validationDate",
      "path" : "Extension.extension",
      "sliceName" : "validationDate",
      "short" : "Date du contrôle de cohérence à partir des traits portés par un dispositif d'identification à haut niveau de confiance | Date of the consistency check performed against the identity traits carried by a high-level-of-confidence identification device",
      "definition" : "Date à laquelle l'identité a été vérifiée sur la base de la pièce justificative contrôlée (cf. sous-extension `validationMode`). | Date at which the identity was verified based on the checked supporting document (see the `validationMode` sub-extension).",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Extension.extension:validationDate.extension",
      "path" : "Extension.extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.extension:validationDate.url",
      "path" : "Extension.extension.url",
      "fixedUri" : "validationDate"
    },
    {
      "id" : "Extension.extension:validationDate.value[x]",
      "path" : "Extension.extension.value[x]",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "Extension.extension:validationMode",
      "path" : "Extension.extension",
      "sliceName" : "validationMode",
      "short" : "Spécifie le type de document qui a été contrôlé par l'agent d'admission pour justifier le statut de l'identité. Seuls certains types de pièces définis dans le RNIV permettent de valider une identité (CN | PA | CS | ... )",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Extension.extension:validationMode.extension",
      "path" : "Extension.extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.extension:validationMode.url",
      "path" : "Extension.extension.url",
      "fixedUri" : "validationMode"
    },
    {
      "id" : "Extension.extension:validationMode.value[x]",
      "path" : "Extension.extension.value[x]",
      "type" : [{
        "code" : "Coding"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://hl7.fr/ig/fhir/core/ValueSet/fr-core-vs-mode-validation-identity|2.2.0"
      }
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-identity-reliability"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "max" : "0"
    }]
  }
}

```
