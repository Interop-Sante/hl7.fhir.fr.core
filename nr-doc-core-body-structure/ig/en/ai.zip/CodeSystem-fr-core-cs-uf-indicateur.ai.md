# FR Core CodeSystem UF Indicator - indicateur d'une unité fonctionnelle - Guide d'implémentation FR Core v2.2.0

## CodeSystem: FR Core CodeSystem UF Indicator - indicateur d'une unité fonctionnelle 

 
Système de codage permettant de définir les indicateurs d’une unité fonctionnelle. 

This Code system is referenced in the definition of the following value sets:

* [FRCoreValueSetOrganizationUFIndicateur](ValueSet-fr-core-vs-organization-uf-indicateur.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "fr-core-cs-uf-indicateur",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablecodesystem|4.0.1"]
  },
  "language" : "fr-FR",
  "url" : "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-uf-indicateur",
  "version" : "2.2.0",
  "name" : "FRCoreCodeSystemUFIndicateur",
  "title" : "FR Core CodeSystem UF Indicator - indicateur d'une unité fonctionnelle",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-07-21T12:10:10+00:00",
  "publisher" : "Interop'Santé",
  "contact" : [{
    "name" : "Interop'Santé",
    "telecom" : [{
      "system" : "url",
      "value" : "http://interopsante.org"
    }]
  },
  {
    "name" : "InteropSanté",
    "telecom" : [{
      "system" : "email",
      "value" : "fhir@interopsante.org",
      "use" : "work"
    }]
  }],
  "description" : "Système de codage permettant de définir les indicateurs d'une unité fonctionnelle.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 7,
  "concept" : [{
    "code" : "HEB",
    "display" : "Hébergement",
    "definition" : "Hébergement"
  },
  {
    "code" : "SOIN",
    "display" : "Soin",
    "definition" : "Soin"
  },
  {
    "code" : "ADMIN",
    "display" : "Administrative",
    "definition" : "Administrative"
  },
  {
    "code" : "MED",
    "display" : "Médicale",
    "definition" : "Médicale"
  },
  {
    "code" : "TECH",
    "display" : "Technique",
    "definition" : "Technique"
  },
  {
    "code" : "MEDICOTECH",
    "display" : "Médico technique (radio, scanner, ...)",
    "definition" : "Médico technique (radio, scanner, ...)"
  },
  {
    "code" : "MAG",
    "display" : "Magasin",
    "definition" : "Magasin"
  }]
}

```
