# FRCorePatientINSExample - Guide d'implémentation FR Core v2.2.0

## Exemple Patient: FRCorePatientINSExample

-------

**French**

-------

Profil: [FR Core Patient INS Profile](StructureDefinition-fr-core-patient-ins.md)

Pierre Durand (official) Male, Date de Naissance :1974-12-25 ( NIR définitif (use: official, ))

-------

| | | | |
| :--- | :--- | :--- | :--- |
| Actif : | true | Décédé : | false |
| Coordonnées | * ph: 01 23 24 67 89(Home)
* ph: 01 99 88 77 66(Work)
* ph: 06 80 55 34 33(Mobile)
* 367 rue Troussier, 45100 Orléans, France(home)
 | | |
| Contact : | * Marie Durand 
* Relations :personne à prévenir en cas d'urgence, Mère
 | | |
| Patient Nationality: | * code: France (la)
 | | |
| [FR Core Patient Birthdate Update Indicator Extension](StructureDefinition-fr-core-patient-birthdate-update-indicator.md) | false | | |
| [Patient Birth Place](http://hl7.org/fhir/extensions/5.3.0/StructureDefinition-patient-birthPlace.html) | Ambléon | | |
| FR Core Patient Ident Reliability Extension: | * identityStatus: [FR Core CodeSystem Fiabilité Identité: QUAL](CodeSystem-fr-core-cs-identity-reliability.md#fr-core-cs-identity-reliability-QUAL) (Identité qualifiée)
 | | |



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "FRCorePatientINSExample",
  "meta" : {
    "profile" : ["https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-patient-ins"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/patient-birthPlace",
    "valueAddress" : {
      "extension" : [{
        "url" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-address-insee-code",
        "valueCoding" : {
          "system" : "https://mos.esante.gouv.fr/NOS/TRE_R13-CommuneOM/FHIR/TRE-R13-CommuneOM",
          "code" : "01006"
        }
      }],
      "city" : "Ambléon"
    }
  },
  {
    "extension" : [{
      "url" : "identityStatus",
      "valueCoding" : {
        "system" : "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-identity-reliability",
        "code" : "QUAL"
      }
    }],
    "url" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-identity-reliability"
  },
  {
    "extension" : [{
      "url" : "code",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "urn:iso:std:iso:3166",
          "code" : "FR",
          "display" : "France (la)"
        }]
      }
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/patient-nationality"
  },
  {
    "url" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-patient-birthdate-update-indicator",
    "valueBoolean" : false
  }],
  "identifier" : [{
    "use" : "official",
    "type" : {
      "coding" : [{
        "system" : "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-v2-0203",
        "code" : "INS-NIR"
      }]
    },
    "system" : "urn:oid:1.2.250.1.213.1.4.8",
    "value" : "123456789012244"
  }],
  "active" : true,
  "name" : [{
    "extension" : [{
      "url" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-patient-birth-list-given-name",
      "valueString" : "Pierre Yves"
    }],
    "use" : "official",
    "family" : "Durand",
    "given" : ["Pierre"]
  }],
  "telecom" : [{
    "system" : "phone",
    "value" : "01 23 24 67 89",
    "use" : "home"
  },
  {
    "system" : "phone",
    "value" : "01 99 88 77 66",
    "use" : "work",
    "rank" : 1
  },
  {
    "system" : "phone",
    "value" : "06 80 55 34 33",
    "use" : "mobile",
    "rank" : 2
  }],
  "gender" : "male",
  "birthDate" : "1974-12-25",
  "deceasedBoolean" : false,
  "address" : [{
    "use" : "home",
    "type" : "both",
    "text" : "367 rue Troussier, 45100 Orléans, France",
    "line" : ["367 rue Troussier"],
    "city" : "Orléans",
    "postalCode" : "45100",
    "period" : {
      "start" : "2018-06-01"
    }
  }],
  "contact" : [{
    "extension" : [{
      "url" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-comment",
      "valueString" : "Mère du patient, à contacter en priorité"
    },
    {
      "url" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-patient-contact-identifier",
      "valueIdentifier" : {
        "system" : "urn:oid:1.2.250.1.213.1.4.8",
        "value" : "C98765"
      }
    }],
    "relationship" : [{
      "extension" : [{
        "url" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-patient-contact-relationship-category",
        "valueCode" : "role"
      }],
      "coding" : [{
        "system" : "https://mos.esante.gouv.fr/NOS/TRE_R260-HL7RoleClass/FHIR/TRE-R260-HL7RoleClass",
        "code" : "ECON",
        "display" : "personne à prévenir en cas d'urgence"
      }]
    },
    {
      "extension" : [{
        "url" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-patient-contact-relationship-category",
        "valueCode" : "relationType"
      }],
      "coding" : [{
        "system" : "https://mos.esante.gouv.fr/NOS/TRE_R216-HL7RoleCode/FHIR/TRE-R216-HL7RoleCode",
        "code" : "MTH",
        "display" : "Mère"
      }]
    }],
    "name" : {
      "family" : "Durand",
      "given" : ["Marie"]
    }
  }]
}

```
