# FR Core CodeSystem v2-3307 - Guide d'implémentation FR Core v2.2.0

## CodeSystem: FR Core CodeSystem v2-3307 

 
HL7 v2 - Table 3307 

This Code system is referenced in the definition of the following value sets:

* [FRCoreValueSetOrganizationEtablissementType](ValueSet-fr-core-vs-organization-etablissement-type.md)
* [FRCoreValueSetOrganizationType](ValueSet-fr-core-vs-organization-type.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "fr-core-cs-v2-3307",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablecodesystem|4.0.1"]
  },
  "language" : "fr-FR",
  "url" : "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-v2-3307",
  "version" : "2.2.0",
  "name" : "FRCoreCodeSystemv2_3307",
  "title" : "FR Core CodeSystem v2-3307",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-08-10T13:54:17+00:00",
  "publisher" : "Interop'Santé",
  "contact" : [{
    "name" : "Interop'Santé",
    "telecom" : [{
      "system" : "url",
      "value" : "http://interopsante.org"
    }]
  },
  {
    "name" : "InteropSanté",
    "telecom" : [{
      "system" : "email",
      "value" : "fhir@interopsante.org",
      "use" : "work"
    }]
  }],
  "description" : "HL7 v2 - Table 3307",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 14,
  "concept" : [{
    "code" : "GHT",
    "display" : "Groupement hospitalier de territoire",
    "definition" : "Groupement hospitalier de territoire"
  },
  {
    "code" : "LEGAL-ENTITY",
    "display" : "Entité légale",
    "definition" : "Entité légale"
  },
  {
    "code" : "GEOGRAPHICAL-ENTITY",
    "display" : "Entité géographique",
    "definition" : "Entité géographique"
  },
  {
    "code" : "GROUP",
    "display" : "Groupe privé/hospitalier",
    "definition" : "Groupe privé/hospitalier"
  },
  {
    "code" : "STRUCT-INTERNE",
    "display" : "Structure interne",
    "definition" : "Structure interne"
  },
  {
    "code" : "SECTEUR",
    "display" : "Secteur",
    "definition" : "Secteur"
  },
  {
    "code" : "DEPARTEMENT",
    "display" : "Département",
    "definition" : "Département"
  },
  {
    "code" : "SERVICE",
    "display" : "Service",
    "definition" : "Service"
  },
  {
    "code" : "UM",
    "display" : "Unité médicale",
    "definition" : "Unité médicale"
  },
  {
    "code" : "UAC",
    "display" : "Unité d'activité",
    "definition" : "Unité d'activité"
  },
  {
    "code" : "POLE",
    "display" : "Pôle",
    "definition" : "Pôle"
  },
  {
    "code" : "CENTRE-RESP",
    "display" : "Centre de responsabilité",
    "definition" : "Centre de responsabilité"
  },
  {
    "code" : "CENTRE-ACTIVITE",
    "display" : "Centre d'activité",
    "definition" : "Centre d'activité"
  },
  {
    "code" : "UF",
    "display" : "Unité fonctionnelle",
    "definition" : "Unité fonctionnelle"
  }]
}

```
