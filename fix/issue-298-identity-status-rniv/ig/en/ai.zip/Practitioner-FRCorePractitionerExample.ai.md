# FRCorePractitionerExample - Guide d'implémentation FR Core v2.2.0

## Example Practitioner: FRCorePractitionerExample

-------

**English**

-------

Last updated: 2025-04-28 18:19:26+0200; Language: fr; 

Information Source: [https://annuaire.sante.fr](https://annuaire.sante.fr)

Profile: [FR Core Practitioner Profile](StructureDefinition-fr-core-practitioner.md)

**FR Core Practitioner Specialty Extension**: [TRE_R38_SpecialiteOrdinale: SM54](https://interop.esante.gouv.fr/terminologies/1.11.1/CodeSystem-TRE-R38-SpecialiteOrdinale.html#TRE-R38-SpecialiteOrdinale-SM54) (Médecine générale (SM))

**identifier**: Identifiant National de Professionnel de Santé/810101201234 (use: official, ), N° RPPS/10101201234 (use: official, )

**active**: true

**name**: Leclerc Sophie

**telecom**: [sophie.leclerc@mssante.fr](mailto:sophie.leclerc@mssante.fr)

> **qualification****code**: Diplôme d'Etat français

> **qualification****code**: Civil



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "FRCorePractitionerExample",
  "meta" : {
    "lastUpdated" : "2025-04-28T18:19:26.335+02:00",
    "source" : "https://annuaire.sante.fr",
    "profile" : ["https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-practitioner"]
  },
  "language" : "fr",
  "extension" : [{
    "url" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-practitioner-specialty",
    "valueCoding" : {
      "system" : "https://mos.esante.gouv.fr/NOS/TRE_R38-SpecialiteOrdinale/FHIR/TRE-R38-SpecialiteOrdinale",
      "code" : "SM54",
      "display" : "Médecine générale (SM)"
    }
  }],
  "identifier" : [{
    "use" : "official",
    "type" : {
      "coding" : [{
        "system" : "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-v2-0203",
        "code" : "IDNPS"
      }]
    },
    "system" : "urn:oid:1.2.250.1.71.4.2.1",
    "value" : "810101201234"
  },
  {
    "use" : "official",
    "type" : {
      "coding" : [{
        "system" : "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-v2-0203",
        "code" : "RPPS"
      }]
    },
    "system" : "https://rpps.esante.gouv.fr",
    "value" : "10101201234"
  }],
  "active" : true,
  "name" : [{
    "text" : "Leclerc Sophie",
    "family" : "Leclerc",
    "given" : ["Sophie"],
    "prefix" : ["MME"],
    "suffix" : ["DR"]
  }],
  "telecom" : [{
    "extension" : [{
      "url" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-contact-point-email-type",
      "valueCoding" : {
        "system" : "https://mos.esante.gouv.fr/NOS/TRE_R256-TypeMessagerie/FHIR/TRE-R256-TypeMessagerie",
        "code" : "MSSANTE",
        "display" : "MSSANTE"
      }
    }],
    "system" : "email",
    "value" : "sophie.leclerc@mssante.fr",
    "use" : "work"
  }],
  "qualification" : [{
    "code" : {
      "coding" : [{
        "system" : "https://mos.esante.gouv.fr/NOS/TRE_R14-TypeDiplome/FHIR/TRE-R14-TypeDiplome",
        "code" : "DE"
      },
      {
        "system" : "https://mos.esante.gouv.fr/NOS/TRE_R48-DiplomeEtatFrancais/FHIR/TRE-R48-DiplomeEtatFrancais",
        "code" : "DE11"
      }]
    }
  },
  {
    "code" : {
      "coding" : [{
        "system" : "https://mos.esante.gouv.fr/NOS/TRE_R09-CategorieProfessionnelle/FHIR/TRE-R09-CategorieProfessionnelle",
        "code" : "C"
      },
      {
        "system" : "https://mos.esante.gouv.fr/NOS/TRE_G15-ProfessionSante/FHIR/TRE-G15-ProfessionSante",
        "code" : "70"
      }]
    }
  }]
}

```
