# FR Core ValueSet Location Position Lit - Guide d'implémentation FR Core v3.0.0-ballot

## ValueSet: FR Core ValueSet Location Position Lit 

 **References** 

* [FR Core Location Extension - Position du lit](StructureDefinition-fr-core-location-position-lit.md)

### Définition logique (CLD)

 

### Expansion

-------

 [Description du (des) tableau(x) ci-dessus](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "fr-core-vs-location-position-lit",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset|4.0.1"]
  },
  "language" : "fr-FR",
  "url" : "https://hl7.fr/ig/fhir/core/ValueSet/fr-core-vs-location-position-lit",
  "version" : "3.0.0-ballot",
  "name" : "FRCoreValueSetLocationPositionLit",
  "title" : "FR Core ValueSet Location Position Lit",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-08T15:58:11+00:00",
  "publisher" : "Interop'Santé",
  "contact" : [{
    "name" : "Interop'Santé",
    "telecom" : [{
      "system" : "url",
      "value" : "http://interopsante.org"
    }]
  },
  {
    "name" : "InteropSanté",
    "telecom" : [{
      "system" : "email",
      "value" : "fhir@interopsante.org",
      "use" : "work"
    }]
  }],
  "description" : "Position du lit dans la chambre",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-location-position-lit",
      "version" : "3.0.0-ballot"
    }]
  }
}

```
