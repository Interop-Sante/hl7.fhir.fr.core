# FR Core Schedule Profile - Guide d'implémentation FR Core v3.0.0-ballot

## Resource Profile: FR Core Schedule Profile 

**Usages:**

* Refer to this Profile: [FR Core Slot Profile](StructureDefinition-fr-core-slot.md)
* Examples for this Profile: [Schedule/FRCoreScheduleExample](Schedule-FRCoreScheduleExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/hl7.fhir.fr.core|current/StructureDefinition/StructureDefinition-fr-core-schedule.json)

### Formal Views of Profile Content

 [Description Differentials, Snapshots, and other representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-fr-core-schedule.csv), [Excel](../StructureDefinition-fr-core-schedule.xlsx), [Schematron](../StructureDefinition-fr-core-schedule.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "fr-core-schedule",
  "url" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-schedule",
  "version" : "3.0.0-ballot",
  "name" : "FRCoreScheduleProfile",
  "title" : "FR Core Schedule Profile",
  "status" : "active",
  "date" : "2026-10-08T19:08:49+00:00",
  "publisher" : "Interop'Santé",
  "contact" : [{
    "name" : "Interop'Santé",
    "telecom" : [{
      "system" : "url",
      "value" : "http://interopsante.org"
    }]
  },
  {
    "name" : "InteropSanté",
    "telecom" : [{
      "system" : "email",
      "value" : "fhir@interopsante.org",
      "use" : "work"
    }]
  }],
  "description" : "Profile of the Schedule resource for France. This profile redefines the element serviceType to associate the service with the duration of this service. It also adds an extension sepcifying the periods of avalability/non-availabilty times of the Schedule\r\n\nProfil de la ressource Schedule pour l'usage en France. Ce profil redéfinit l'élément serviceType de façon à associer le service avec la durée du service. Il ajoute également une extension qui précise les périodes de disponibilités/non disponibilités de la vacation.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "ical",
    "uri" : "http://ietf.org/rfc/2445",
    "name" : "iCalendar"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Schedule",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Schedule|4.0.1",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Schedule",
      "path" : "Schedule"
    },
    {
      "id" : "Schedule.meta.profile",
      "path" : "Schedule.meta.profile",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this"
        }],
        "description" : "Slice based on the canonical url value",
        "rules" : "open"
      }
    },
    {
      "id" : "Schedule.meta.profile:fr-canonical",
      "path" : "Schedule.meta.profile",
      "sliceName" : "fr-canonical",
      "min" : 0,
      "max" : "1",
      "patternCanonical" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-schedule|3.0.0-ballot"
    },
    {
      "id" : "Schedule.extension",
      "path" : "Schedule.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "rules" : "open"
      }
    },
    {
      "id" : "Schedule.extension:serviceTypeDuration",
      "path" : "Schedule.extension",
      "sliceName" : "serviceTypeDuration",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-service-type-duration|3.0.0-ballot"]
      }]
    },
    {
      "id" : "Schedule.extension:availabilityTime",
      "path" : "Schedule.extension",
      "sliceName" : "availabilityTime",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-schedule-availability-time|3.0.0-ballot"]
      }]
    },
    {
      "id" : "Schedule.serviceCategory",
      "path" : "Schedule.serviceCategory",
      "max" : "1"
    },
    {
      "id" : "Schedule.serviceType",
      "path" : "Schedule.serviceType",
      "max" : "0"
    },
    {
      "id" : "Schedule.specialty",
      "path" : "Schedule.specialty",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://hl7.fr/ig/fhir/core/ValueSet/fr-core-vs-practitioner-specialty|3.0.0-ballot"
      }
    },
    {
      "id" : "Schedule.actor",
      "path" : "Schedule.actor",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Device|4.0.1",
        "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-practitioner-role|3.0.0-ballot",
        "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-related-person|3.0.0-ballot",
        "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-healthcare-service|3.0.0-ballot",
        "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-location|3.0.0-ballot",
        "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-patient|3.0.0-ballot",
        "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-practitioner|3.0.0-ballot"]
      }]
    }]
  }
}

```
