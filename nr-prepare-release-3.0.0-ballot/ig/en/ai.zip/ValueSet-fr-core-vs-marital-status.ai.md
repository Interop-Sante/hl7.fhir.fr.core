# FR Core ValueSet Marital Status ValueSet - Guide d'implémentation FR Core v3.0.0-ballot

## ValueSet: FR Core ValueSet Marital Status ValueSet 

 **References** 

* [FR Core Patient Profile](StructureDefinition-fr-core-patient.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "fr-core-vs-marital-status",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset|4.0.1"]
  },
  "language" : "fr-FR",
  "url" : "https://hl7.fr/ig/fhir/core/ValueSet/fr-core-vs-marital-status",
  "version" : "3.0.0-ballot",
  "name" : "FRCoreValueSetMaritalStatus",
  "title" : "FR Core ValueSet Marital Status ValueSet",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-08T19:08:49+00:00",
  "publisher" : "Interop'Santé",
  "contact" : [{
    "name" : "Interop'Santé",
    "telecom" : [{
      "system" : "url",
      "value" : "http://interopsante.org"
    }]
  },
  {
    "name" : "InteropSanté",
    "telecom" : [{
      "system" : "email",
      "value" : "fhir@interopsante.org",
      "use" : "work"
    }]
  }],
  "description" : "Patient Marital Status",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-marital-status",
      "version" : "3.0.0-ballot"
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/v3-MaritalStatus",
      "version" : "5.0.0"
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/v3-NullFlavor",
      "version" : "4.0.0",
      "concept" : [{
        "code" : "UNK",
        "display" : "unknown"
      }]
    }]
  }
}

```
