# Historique des changements - Guide d'implémentation FR Core v2.2.0

## Historique des changements

 
There is no translation page available for the current page, so it has been rendered in the default language 

### Release 3.0.0 de l’Implementation Guide FRCore

[Modifications apportées dans la release 3.0.0](https://github.com/Interop-Sante/hl7.fhir.fr.core/milestone/12?closed=1) :

* Mise à jour de la dépendance vers EU Core 2.0.0 : les profils FRCoreOrganization, FRCorePatient, FRCorePatientINS, FRCorePractitioner, FRCorePractitionerRole, FRCoreLocation héritent des profils EU Core correspondants, et FRCoreAddress hérite du profil Address (EU) [#300](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/300) 
* FRCoreOrganization : `name` devient obligatoire
* **[BREAKING CHANGE]** FRCorePatient et FRCorePatientINS : suppression de la slice `nationality` référençant l’extension FR Core `fr-core-patient-nationality` au profit de l’extension internationale héritée via EU Core. Les ressources utilisant l’URL `https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-patient-nationality` doivent être mises à jour.
* FRCorePractitioner : obligation d’avoir un `identifier` ou un `name`
* FRCoreAddress : ajout des extensions internationales `streetName`, `houseNumber`, `postBox`, `countryCode` (déjà utilisées dans le cadre de l’AS)
* Possibilité d’utiliser l’extension `data-absent-reason` si un attribut obligatoire ne peut pas être renseigné
 
* Mise à jour des dépendances : remplacement de `hl7.fhir.extensions.r5` par `hl7.fhir.uv.xver-r5.r4`, ajout de `hl7.fhir.eu.base: 2.0.0` [#300](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/300)
* Ajout d’une section sur la gestion des champs obligatoires manquants (`data-absent-reason`) dans les bonnes pratiques [#300](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/300)
* Mise à jour des participants aux groupes de travail [#295](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/295)
* Ajout d’exemples et corrections QA [#296](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/296) 
* Ajout de 5 nouveaux exemples : `FRCorePatientDeceasedExample`, `FRCoreRelatedPersonExample`, `FRCoreObservationRespRateExample`, `FRCoreMedicationAdministrationInhaledOxygenExample`, `FRCoreObservationOxygenSaturationExample`
* Enrichissement de `FRCorePatientINSExample` (renommé depuis `FRCorePatientExample`) et `FRCorePractitionerExample`
* Corrections QA : code système nationality (`urn:iso:std:iso:3166`), display names SNOMED CT et TRE-R38, définitions manquantes dans les CodeSystems `v2-3307`, `TypeChambre`, `PositionLit`
 

#### Refonte de l’extension fr-core-identity-reliability (RNIV EXI SI 07)

**[BREAKING CHANGE]** Conformité au référentiel d’identitovigilance et au référentiel INS : refonte de l’extension `fr-core-identity-reliability` (statuts de confiance, canal et date de collecte, annotations complémentaires) — voir détail ci-dessous [#306](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/306)

##### Remplacement du CodeSystem fr-core-cs-v2-0445 par deux CodeSystems dédiés

Le CodeSystem `fr-core-cs-v2-0445` (table HL7 v2 0445, 23 codes mélangeant statuts et attributs complémentaires) ainsi que le CodeSystem `fr-core-cs-fiabilite-identite` (doublon inutilisé du précédent) sont **supprimés**, remplacés par deux CodeSystems au périmètre explicite :

* `fr-core-cs-identity-status` (`FRCoreCodeSystemIdentityStatus`) : les 4 statuts de confiance RNIV.

| | | | |
| :--- | :--- | :--- | :--- |
| `PROV` | Identité provisoire | − | − |
| `RECUP`**(nouveau)** | Identité récupérée | + | − |
| `VALI` | Identité validée | − | + |
| `QUAL`**(nouveau)** | Identité qualifiée | + | + |

* `fr-core-cs-identity-status-comment` (`FRCoreCodeSystemIdentityStatusComment`) **(nouveau)** : les 19 autres codes de l’ancien `fr-core-cs-v2-0445` (attributs RNIV — homonyme, fictif, douteux — et codes de gestion — doublon, désactivé, collision…), destinés à la sous-extension `comment`.

**Impact pour les implémenteurs** : toute référence à `fr-core-cs-v2-0445` ou `fr-core-cs-fiabilite-identite` doit être mise à jour vers l’un de ces deux nouveaux CodeSystems selon le code utilisé.

##### ValueSets identityStatus et comment

Le ValueSet `fr-core-vs-identity-status` (`FRCoreValueSetIdentityStatus`) est réduit aux 4 statuts RNIV (`fr-core-cs-identity-status`). Le binding de la sous-extension `identityStatus` passe de `extensible` (tous les codes `v2-0445`) à `required` (ces 4 valeurs uniquement).

**Impact pour les implémenteurs** : les ressources utilisant des codes autres que `PROV`, `RECUP`, `VALI` ou `QUAL` dans `identityStatus` (ex. `DOUB`, `FICT`, `DOUT`…) doivent migrer ces valeurs vers la nouvelle sous-extension `comment`, désormais bindée en `extensible` sur le nouveau ValueSet `fr-core-vs-identity-status-comment` (`FRCoreValueSetIdentityStatusComment`).

Dans les versions précédentes, les annotations complémentaires pouvaient être portées dans `identityStatus` :

```
{
  "url": "identityStatus",
  "valueCoding": {
    "system": "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-v2-0445",
    "code": "DOUB"
  }
}

```

À partir de cette version, elles doivent être portées dans `comment` :

```
{
  "url": "comment",
  "valueCoding": {
    "system": "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-identity-status-comment",
    "code": "DOUB"
  }
}

```

##### Canal d’obtention et date d’interrogation du téléservice INSi : sous-extensions methodCollection et dateInterrogationINSi

La sous-extension `methodCollection` documente le canal par lequel les traits d’identité ou le matricule INS ont été obtenus (saisie manuelle, carte Vitale, téléservice INSi, code à barre/Datamatrix, puce RFID, Application carte Vitale) — une information de traçabilité (RNIV §4.3), distincte du statut de confiance résultant (`identityStatus`) et de la pièce justificative contrôlée (`validationMode`). Un `^definition` a été ajouté pour préciser cette portée, et le code `AV` (Application carte Vitale) a été ajouté au CodeSystem `fr-core-cs-identity-method-collection`, pour distinguer explicitement la carte Vitale physique de sa version dématérialisée (RNIV §4.3.4) [#334](https://github.com/Interop-Sante/hl7.fhir.fr.core/issues/334).

**[BREAKING CHANGE]** La sous-extension `dateCollection` est renommée `dateInterrogationINSi`, pour l’aligner sur le champ `ZFD-6` “Date d’interrogation du téléservice INSi” d’IHE PAM France (v2.11.1, §6.18.6). Son `^definition` précise qu’elle est renseignée chaque fois que le téléservice INSi est appelé — par lecture de la carte Vitale ou par saisie directe des traits (RNIV §4.3.1-4.3.3) — à l’exception des usagers de l’Application carte Vitale et de leurs ayants droit, pour lesquels le RNIV exclut explicitement cet appel (§4.1). Elle ne doit pas être confondue avec la date de vérification de l’identité (`validationDate`) [#336](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/336).

**Impact pour les implémenteurs** : les ressources utilisant la sous-extension à l’URL `dateCollection` doivent être mises à jour vers `dateInterrogationINSi`.

##### Annotations complémentaires : comment passe en CodeableConcept

La sous-extension `comment` n’acceptait qu’un `Coding` du ValueSet `fr-core-vs-identity-status-comment`. Elle accepte désormais un `CodeableConcept`, ce qui permet de saisir du texte libre (`.text`) en complément ou à la place d’un code de ce ValueSet [#306](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/306).

##### Correction des invariants fr-core-1, fr-core-2, fr-core-3

Les invariants conditionnaient leur vérification au statut `VALI`. Ils ciblent désormais `QUAL`, conformément à l’exigence EXI SI 08 :

> « Seul le statut Identité qualifiée permet le référencement des données de santé échangées avec le matricule INS. »

**Impact pour les implémenteurs** : une ressource `FRCorePatientINS` portant un matricule INS doit avoir le statut `QUAL` (et non `VALI`). Les instances existantes au statut `VALI` avec un matricule INS présent ne passeront plus la validation — le statut doit être mis à jour en `QUAL`.

##### Invariants sur les attributs “douteux” et “fictif” (RNIV EXI SI 09)

Ajout de 2 invariants sur `fr-core-identity-reliability`, pour rendre conforme le profil au volet statut de l’exigence [EXI SI 09] du RNIV (§3.2.3) : une identité portant l’attribut `comment` “Identité douteuse” (`DOUT`) ou “Identité fictive” (`FICT`) doit avoir un statut de confiance (`identityStatus`) égal à “Identité provisoire” (`PROV`). Un second invariant interdit le cumul des attributs “Identité fictive” et “Identité douteuse” sur une même identité [#335](https://github.com/Interop-Sante/hl7.fhir.fr.core/issues/335).

##### identityStatus obligatoire dans FRCorePatientINSProfile

La cardinalité de `identityStatus` passe de `0..1` à `1..1` dans le profil Patient INS pour satisfaire EXI SI 07.

### Release 2.2.0 de l’Implementation Guide FRCore

[Modifications apportées dans la release 2.2.0](https://github.com/Interop-Sante/hl7.fhir.fr.core/milestone/10?closed=1) :

* Restructuration des profils Organization avec : 
* Simplification du profil de base FRCoreOrganizationProfile
* Création du nouveau profil FRCoreOrganizationEtablissementProfile pour les établissements
* Suppression du profil FRCoreOrganizationPoleProfile
* Refonte des profils FRCoreOrganizationUFProfile, FRCoreOrganizationUACProfile et FRCoreLocationProfile
 
* Amélioration du profil Location pour mieux supporter la structuration hospitalière (chambres, lits)
* Ajout de 8 nouveaux CodeSystems et 11 nouveaux ValueSets pour supporter ces structures 
* Nouveaux CodeSystems ajoutés : 
* FRCoreCodeSystemChampActiviteField : Champ d’activité clinique (MCO, SMR, HAD, PSY, EHPAD, etc.)
* FRCoreCodeSystemCodeTarifTNJP : Codes tarifaires TNJP
* FRCoreCodeSystemDisciplineEquipement : Discipline d’équipement
* FRCoreCodeSystemDisciplinePrestation : Discipline de prestation
* FRCoreCodeSystemPositionLit : Position du lit dans la chambre
* FRCoreCodeSystemTypeActivite : Type d’activité
* FRCoreCodeSystemTypeChambre : Type de chambre
* FRCoreCodeSystemUFIndicateur : Indicateurs UF
 
* CodeSystems modifiés : 
* FRCoreCodeSystemLocationType : Ajout de codes pour lit et chambre
* FRCoreCodeSystemv2-3307
 
* Nouveaux ValueSets ajoutés : 
* FRCoreValueSetCategorieSAEEtablissement
* FRCoreValueSetLocationPositionLit (remplace LocationPositionRoom)
* FRCoreValueSetLocationTypeChambre
* FRCoreValueSetOrganizationChampActivite (remplace OrganizationActivityField)
* FRCoreValueSetOrganizationCodeTarifTNJP
* FRCoreValueSetOrganizationDisciplineEquipement
* FRCoreValueSetOrganizationDisciplinePrestation
* FRCoreValueSetOrganizationEtablissementType
* FRCoreValueSetOrganizationTypeActivite
* FRCoreValueSetOrganizationUACType
* FRCoreValueSetOrganizationUFIndicateur
 
* ValueSets supprimés : 
* FRCoreValueSetLocationIdentifierType
* FRCoreValueSetLocationPhysicalType
* FRCoreValueSetLocationPositionRoom
* FRCoreValueSetOrganizationActivityField
* FRCoreValueSetOrganizationUFActivityField
 
* ValueSets modifiés : 
* FRCoreValueSetLocationType
* FRCoreValueSetOrganizationType
 
 
* Refonte des extensions Organization avec renommage et réorganisation 
* Nouvelles extensions Organization : 
* FRCoreOrganizationChampActiviteExtension (remplace ActivityFieldExtension)
* FRCoreOrganizationDemandeuseActeExtension (remplace ApplicantActExtension)
* FRCoreOrganizationDisciplineEquipementExtension
* FRCoreOrganizationDisciplinePrestationExtension
* FRCoreOrganizationExecutanteActeExtension (remplace ExecutantExtension)
* FRCoreOrganizationExterneExtension (remplace ExternalExtension)
* FRCoreOrganizationMemberExtension
* FRCoreOrganizationPlaceHebergementTheoriqueExtension (remplace TotalNumberOfTheoricalAccomodationSpaceExtension)
* FRCoreOrganizationRaisonSocialeExtension
* FRCoreOrganizationSAECategoryExtension
* FRCoreOrganizationTarifExtension
* FRCoreOrganizationTypeActiviteExtension (remplace ActivityTypeExtension)
* FRCoreOrganizationUFIndicateurExtension
 
* Extensions Organization supprimées : 
* FRCoreOrganizationActivityFieldExtension
* FRCoreOrganizationActivityTypeExtension
* FRCoreOrganizationAnalysisSectionExtension
* FRCoreOrganizationApplicantActExtension
* FRCoreOrganizationBudgetLetterExtension
* FRCoreOrganizationDescriptionExtension
* FRCoreOrganizationExecutantExtension
* FRCoreOrganizationExternalExtension
* FRCoreOrganizationFieldExtension
* FRCoreOrganizationPrestationDisciplineExtension
* FRCoreOrganizationTotalNumberOfTheoricalAccomodationSpaceExtension
 
* Nouvelles extensions Location : 
* FRCoreLocationPositionLitExtension (position du lit dans la chambre)
* FRCoreLocationTypeChambreExtension (type de chambre)
 
* Extensions Location supprimées : 
* FRCoreLocationPartOfPositionRoomExtension
* FRCoreLocationUsePeriodExtension
 
* Extensions modifiées : 
* FRCoreOrganizationShortNameExtension
 
 
* Ajout de 14 nouveaux exemples illustrant la hiérarchie organisationnelle (EJ, EG, pôles, départements, services, UF, UAC, lieux)
* Patient.extension[nationality] : passage de la cardinalité 0..1 à 0..* (un patient peut avoir plusieurs nationalités) [#265](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/265)
* Patient.extension[deathPlace] Passage du datatype string à Address pour être uniforme avec birthPlace. Le mode string est toujours possible avec l’attribut Address.line [#265](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/265)

Dans la version 2.1.0, le lieu de naissance était indiqué dans une extension de type `string`.

```
{
  "resourceType" : "Patient",
  "extension" : [
    {
      "url" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-patient-death-place",
      "valueString" : "27 rue des Tilleuls, 34070 Montpellier"
    }
  ]
}

```

A partir de la version 2.2.0, le lieu de naissance est indiqué dans une extension de type `address`. Indiquer une adresse sous forme de chaîne de caractères reste possible grâce à l’attribut `Address.line`.

```
{
  "resourceType" : "Patient",
  "extension" : [
    {
      "url" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-patient-death-place",
      "valueAddress" : {
        "line" : "27 rue des Tilleuls, 34070 Montpellier"
      }
    }
  ]
}

```

* Mise à jour et uniformisation des titres et description des artifacts [#184](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/184) [#186](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/186) [#188](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/188) [#203](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/203) [#209](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/209) [#264](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/264)
* Mise à jour FrCorePatientINSProfile.fsh (correction d’erreurs) [#163](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/163) [#197](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/197)
* Suppression du numéro ADELI suite au décommissionnement national [#189](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/189)
* Mise à jour et uniformisation des cardinalités des identifier (Patient, Practitioner, Organization) [#190](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/190)
* Mise à jour du emailType short dans FRCoreContactPointProfile.fsh [#193](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/193)
* Mise à jour de la page à propos (contribution, version FHIR, bonnes pratiques) [#198](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/198)
* Mise à jour de la requête qui liste les profils [#199](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/199)
* Mise à jour de la description d’idnatps FRCorePractitionerProfile.fsh [#200](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/200)
* Mise à jour du short de idnatstruct FRCoreOrganizationProfile.fsh [#201](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/201)
* Mise à jour de l’URL du CodeSystem des communes (Commune –> CommuneOM) [#204](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/204)
* FIX discriminateur Patient.contact.relationship [#206](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/206)
* Mise à jour du HumanName use (cardinalité et suppression de lignes inutiles héritées) [#208](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/208)
* Ajout de nouvelles méthodes de collectes d’identité dans le cadre de l’INS [#210](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/210)
* Ajout de l’extension MultipleBirth pour indiquer le rang gémellaire d’un patient [#212](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/212)
* Patient: assouplissement de la contrainte sur identifier[PI].use via binding à un VS dédié [#215](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/215)
* Résolution erreurs QA : mise à jour et ajout d’exemples, définition concepts CS, path Extension [#216](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/216)
* Ajout page : bonnes pratiques, problématiques connues, et mise à jour de l’index pour expliciter l’intérêt de FRCore [#220](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/220)
* Ajout de la page change notes pour faciliter l’accès à l’historique des modifications [#221](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/221)
* Mise à jour du texte sur le patient INS sur la définition des identifiants NIR [#227](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/227)
* Relaxation de la contrainte Encounter.subject pour qu’il puisse également pointer un Group [#228](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/228)
* Suppression des contraintes de HumanName sur la civiliteexercice, déplacé dans Practitioner [#230](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/230)
* Refacto - uniformisation des namings et correction QA [#232](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/232)
* Suppression MLLE dans les civilités [#237](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/237)
* Mise à jour identifiants INS Patient [#238](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/238)
* Mise à jour du texte de l’identifiant de l’IDNatStruct de la ressource FRCoreOrganization [#264](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/264)
* MAJ package terminologies à LATEST [#239](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/239)
* Ajout du template InteropSanté [#242](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/242)
* Retrait du genre “other” sur le profil FrCorePatient INS [#243](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/243)
* Mise à jour des profils patient et exemples (quick fix et refacto) [#244](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/244) [#245](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/245)
* Ajout d’un invariant qui renvoie un warning si le COG de naissance 99999 est utilisé pour une identité validée [#262](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/262)
* Ajout du numéro AMELI au profil PractitionerRole [#260](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/260)
* Mise à jour invariant FrCorePatientINSProfile.fsh (correction d’erreur) [#185](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/185)
* Ajout d’informations sur la certification et le répertoire de certifications [#257](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/257)
* Correction d’un jeu de valeurs en erreur (j245) [#258](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/258)
* Mise à jour du narratif FRCore (index.md, bonnes_pratiques.md et known_problems.md) [#259](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/259)
* Réorganisation des alias FSH [#261](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/261)
* Ajout de la contrainte : obligation d’un CodeableConcept sur value[x] pour le type d’activité [#276](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/276)
* Ajout d’un ruleset ValueSet et d’un ruleset CodeSystem (ShareableValueSet / ShareableCodeSystem & langue fr-FR) [#277](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/277)
* Extension nationality : extension du contexte à Person et RelatedPerson [#278](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/278)
* Revue des profils de structure : correction de `members` → `member` (cohérence avec l’extension et le nommage FHIR), suppression du VS UAC inutilisé [#280](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/280)
* Correction orthographique : artifact → artéfact [#282](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/282)
* **[BREAKING CHANGE]** Patient : séparation de la slice `NSS` en deux slices distinctes `NSS-NIR` et `NSS-NIA`, et mise à jour des OID associés [#284](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/284)

Dans la version 2.1.0, le numéro de sécurité sociale était modélisé dans une seule slice `NSS` avec l’OID `1.2.250.1.213.1.4.8`.

```
{
  "resourceType": "Patient",
  "identifier": [
    {
      "type": {
        "coding": [
          {
            "system": "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code": "NH"
          }
        ]
      },
      "system": "urn:oid:1.2.250.1.213.1.4.8",
      "value": "1 69 05 69 123 456 78"
    }
  ]
}

```

À partir de la version 2.2.0, deux slices distinctes permettent de différencier le NIR et le NIA utilisés comme numéro de sécurité sociale, avec des OID spécifiques :

* `NSS-NIR` : NIR utilisé comme numéro de sécurité sociale → `urn:oid:1.2.250.1.213.1.4.13`
* `NSS-NIA` : NIA utilisé comme numéro de sécurité sociale → `urn:oid:1.2.250.1.213.1.4.14`

```
{
  "resourceType": "Patient",
  "identifier": [
    {
      "type": {
        "coding": [
          {
            "system": "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code": "NH"
          }
        ]
      },
      "system": "urn:oid:1.2.250.1.213.1.4.13",
      "value": "1 69 05 69 123 456 78"
    }
  ]
}

```

> **Impact pour les implémenteurs** : les ressources utilisant `identifier[NSS]` avec `system: urn:oid:1.2.250.1.213.1.4.8` doivent être mises à jour. L’OID `1.2.250.1.213.1.4.8` correspond désormais au matricule INS-NIR (porté par le profil PatientINS), et non au numéro de sécurité sociale.

* Ajout de l’invariant fr-core-1 : si l’identité patient est validée, elle doit contenir un matricule INS [#285](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/285)
* Suppression de la contrainte de cardinalité sur Encounter.type [#286](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/286)
* Suppression de l’extension MultipleBirth ajoutée en erreur [#288](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/288)
* Corrections pour la publication : mise à jour des textes sur les UM et l’extension `member`, correction des exemples liés à la structure [#289](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/289)
* Mise à jour de l’identifier type du rpps rang (INTRN → RPPS) [#273](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/273)
* [FIX] Discriminateur Patient.contact.relationship via extension de catégorie [#293](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/293)

### Release 2.1.0 de l’Implementation Guide FRCore

[Modifications apportées dans la release 2.1.0](https://github.com/Interop-Sante/hl7.fhir.fr.core/milestone/9?closed=1) :

* PatientINS: ajout des slices de test et demo pour le NIR, Organization: séparation des slices SIREN & SIRET [#163](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/163)
* Mise à jour du discriminant d’Organization [#166](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/166)
* Suppression des tags MS (copier coller erroné de l’annuaire santé) [#171](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/171)
* Relaxation cardinalité FrPatient.identifier[PI] à 0..* au lieu de 0..1 [#172](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/172)
* Mise à jour de la page index et préparation pour publication [#174](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/174)
* Ajour d’une description du profil FrPractitioner : comment l’utiliser ? [#175](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/175)
* Mise à jour de l’URL de la TRE R13 [#176](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/176)
* Update practitioner qualification discriminator [#180](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/180)
* Préparation publication 2.1.0 [#183](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/183)
* Ajout de la page à propos [#182](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/182)
* Fusion des deux profils PractitionerRole en un seul FRCorePractitionerRole [#61](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/61)
* Add MS Tag to FrCorePatientINS [#167](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/167)
* Uniformisation des noms de profils pour avoir le format FRCore[…] [#179](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/179)
* Ajout d’une intro note pour le profil Patient INS [#169](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/169)

### Release 2.0.1 de l’Implementation Guide FRCore

[Modifications apportées dans la release 2.0.1](https://github.com/Interop-Sante/hl7.fhir.fr.core/milestone/11?closed=1) :

* Suppression des urls interopsante.org au profit de hl7.fr pour FrPractitioner et FrOrganization [#152](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/152)

### Release 2.0.0 de l’Implementation Guide FRCore

[Modifications apportées dans la release 2.0.0](https://github.com/Interop-Sante/hl7.fhir.fr.core/milestone/6?closed=1) :

* Update list (ref. IHE PAM France 2.10) [#68](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/68)
* Fusion des extensions Patient identity : method collection & reliability [#67](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/67)
* Issue #34: Réintégrer les profils FrPractionerRoleExercice & FrPracti… [#42](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/42)
* Add ‘bonnes pratiques’ page & rm location.identifier mandatory [#102](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/102)
* Resolve more qa errors [#96](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/96)
* TRE Commune (R13) URL was wrong [#83](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/83)
* Ajout du code “PACS” dans le marital status [#119](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/119)
* Ajout d’identifier slices pour Fr Core Practitioner et Fr Core Organization [#127](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/127)
* Changement de la cardinalité identifier[NDP] de 0..* à 0..1 [#123](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/123)
* Mise à jour et éclaircissement du Patient identifier [#115](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/115)
* Uniformisation des id des CS et des VS [#121](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/121)
* Mise à jour de la taille de l’encart de la page d’accueil [#132](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/132)
* MAJ NIR - DESCR NIR FrCorePatientINS.fsh + Ajout NSS au FrCorePatient [#129](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/129)
* Correction Encounter.identifier.type binding - system not existing [#136](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/136)
* Fix typo practioner [#137](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/137)
* Ajout exemples [#139](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/139)
* Mise à jour des spécialités [#138](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/138)
* Mise à jour de l’identifiant patient INS [#133](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/133)
* Suppression de lignes inutiles et relâchement de contraintes pour perm ttre l’héritage Annuaire – FrCore [#145](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/145)
* [Style] Maj description des profils, ajout contributeurs, ajout page loste des profils [#146](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/146)
* Update publication-request for release [#147](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/147)
* FrPatient : mise à jour du nom et ajout du titre [#14](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/14)
* Codesystem : uniformisation des name et ajout des title CodeSystem [#13](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/13)
* Mise à jour de l’id ValueSet fr core practitioner pour uniformisation [#9](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/9)
* StructureDefinition - Uniformisation name et ajout des title [#16](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/16)
* ValueSet : uniformisation name et ajout title [#17](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/17)
* Passage au format IG [#54](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/54)
* Ajout des workflows [#55](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/55)
* Ajout des données dans l’ensemble des meta.profile [#59](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/59)
* Mise à jour de Patient.identifier.type [#58](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/58)
* FrPatient : Mise à jour du titre [#15](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/15)
* Suppression classnotes [#65](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/65)
* Suppression slice identityReliability [#57](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/57)
* Création d’un dossier datatype-profiles [#66](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/66)
* FRCorePratitioner : ajout de meta.profile [#56](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/56)
* Ajout du profil FrCorePatientINS et résolution du problème nom de patientt [#64](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/64)
* Ajout gitignore et ajout du profil nationality [#62](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/62)
* Mise à jour des URLs des profils et suppression de profils obsolète [#11](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/11)
* Suppression des bindings des Observation.interpretation [#60](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/60)
* Patient : Utilisation du profil FrAddress dans l’extension birthplace [#63](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/63)
* Création d’un ValueSet pour que Patient.gender INS permette uniquement es valeurs male female unknown [#73](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/73)
* Mise à jour des alias [#76](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/76)
* Correction typo practioner –> practitioner [#79](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/79)
* Modification des urls canoniques http –> https [#69](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/69)
* Suppression du binding identifier.type qui duplique celui hérité de FHIR Core [#70](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/70)
* Correction d’erreurs (espaces en fin de string et ajout d’un title manq ant à un ValueSet) [#94](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/94)
* Cleaning des urls, suppression url interopsanté [#84](https://github.com/Interop-Sante/hl7.fhir.fr.core/pull/84)

### Versions antérieures

La création de ces profils a été initiée en 2017 sur [la plateforme simplifier](https://simplifier.net/frenchprofiledfhirar) (Participants : Eric Dufour, Isabelle Gibaud, François Macary et Yohann Poiron).

En 2024, l’ensemble des ressources de conformité a été mis au sein de ce [guide d’implémentation](https://hl7.fr/ig/fhir/core) pour simplifier leur usage et leur accès, rendant les anciens profils simplifier obsolètes (Participants : Marie Brulliard, Sylvain Demey, Isabelle Gibaud, Yohann Poiron et Nicolas Riss).

