# Problématiques connues - Guide d'implémentation FR Core v3.0.0-ballot

## Problématiques connues

Les problématiques connues nécessitent le retour de l’écosystème, n’hésitez pas à remonter de nouvelles problématiques ou à faire des retours sur ces problématiques [sur GitHub](https://github.com/Interop-Sante/hl7.fhir.fr.core/issues).

* Le guide contient un grand nombre d’extensions, il est probable qu’un certain nombre d’entre elles puissent être supprimées pour être remplacées par : d’autres ressources, des attributs ajoutés dans R5/R6, d’autres champs natifs …
* Relicats historiques d’OID qui doivent être remplacés par des URL canoniques
* Certains profils et extensions n’ont pas d’exemples associés
* Les artifacts terminologiques ne sont pas uniformisés parmi tous les standards d’InteropSanté

