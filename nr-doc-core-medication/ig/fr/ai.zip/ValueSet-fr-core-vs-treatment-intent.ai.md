# FR Core ValueSet Treatment Intent - Guide d'implémentation FR Core v2.2.0

## ValueSet: FR Core ValueSet Treatment Intent 

 
Jeu de valeurs SNOMED CT pour l’intention globale du traitement (MedicationRequest). 

 **References** 

* [FR Core MedicationRequest Treatment Intent Extension](StructureDefinition-fr-core-treatment-intent.md)

### Définition logique (CLD)

 

### Expansion

-------

 [Description du (des) tableau(x) ci-dessus](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "fr-core-vs-treatment-intent",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset|4.0.1"]
  },
  "language" : "fr-FR",
  "url" : "https://hl7.fr/ig/fhir/core/ValueSet/fr-core-vs-treatment-intent",
  "version" : "2.2.0",
  "name" : "FRCoreValueSetTreatmentIntent",
  "title" : "FR Core ValueSet Treatment Intent",
  "status" : "active",
  "date" : "2026-07-16T11:52:18+00:00",
  "publisher" : "Interop'Santé",
  "contact" : [{
    "name" : "Interop'Santé",
    "telecom" : [{
      "system" : "url",
      "value" : "http://interopsante.org"
    }]
  },
  {
    "name" : "InteropSanté",
    "telecom" : [{
      "system" : "email",
      "value" : "fhir@interopsante.org",
      "use" : "work"
    }]
  }],
  "description" : "Jeu de valeurs SNOMED CT pour l'intention globale du traitement (MedicationRequest).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "filter" : [{
        "property" : "concept",
        "op" : "is-a",
        "value" : "363675004"
      }]
    }]
  }
}

```
